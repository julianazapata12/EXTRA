﻿using COMPILADOR_EXTRACLASE.CACHE;
using COMPILADOR_EXTRACLASE.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class COMPILADOR_EXTRACLASE.AnalisisLexicoTexto
{

    public class AnalizadorLexicoTexto
{
    private int numeroLineaActual = 0;
    private string contenidoLineaActual = "";
    private int puntero = 0;
    private string caracterActual = "";
    private string lexema = "";
    private string Categoria = "";
    private string estadoActual = "";
    private int posicionInicial = 0;
    private int posicionFinal = 0;
    private bool continuarAnalisis = false;

    public AnalizadorLexicoTexto()
    {
        CargarNuevaLinea();
    }
    private void CargarNuevaLinea()
    {
        if (!"@eof@".Equals(contenidoLineaActual))
        {
            numeroLineaActual += 1;
            contenidoLineaActual = DataCache.ObtenerLinea(numeroLineaActual).Contenido;
            numeroLineaActual = DataCache.ObtenerLinea(numeroLineaActual).NumeroLinea;
            puntero = 1;
        }


    }

    private void LeerSiguienteCaracter()
    {
        if (!"@eof@".Equals(contenidoLineaActual))
        {
            caracterActual = "@eof@";
        }
        else if (puntero > contenidoLineaActual.Length)
        {
            caracterActual = "@eof@";
        }
        else
        {
            caracterActual = contenidoLineaActual.Substring(puntero - 1, 1);
            puntero = puntero + 1;

        }

        //PARA VER RESULTADOS
        while ("@EOF".Equals(caracterActual))
        {
            DevolverSiguienteComponente();
        }

    }

    private void DevolverPuntero()
    {
        puntero -= 1;

    }
    private void Concatenar()
    {
        lexema += caracterActual;

    }

    private void Resetear()
    {
        estadoActual = "q0";
        lexema = "";
        Categoria = "";
        posicionInicial = 0;
        posicionFinal = 0;
        caracterActual = "";
        continuarAnalisis = true;
    }


    public void DevolverSiguienteComponente()
    {
        Resetear();
        while (continuarAnalisis)
        {
            else if ("q1".Equals(estadoActual))
            {
                ProcesarEstado1();
            }
            else if ("q2".Equals(estadoActual))
            {
                ProcesarEstado2();
            }
            else if ("q3".Equals(estadoActual))
            {
                ProcesarEstado3();
            }
            else if ("q4".Equals(estadoActual))
            {
                ProcesarEstado4();
            }
            else if ("q5".Equals(estadoActual))
            {
                ProcesarEstado5();
            }
            else if ("q6.Equals(estadoActual))
            {
                ProcesarEstado6();
            }
            else if ("q7".Equals(estadoActual))
            {
                ProcesarEstado7();
            }
            else if ("q8".Equals(estadoActual))
            {
                ProcesarEstado8();
            }
            else if ("q9".Equals(estadoActual))
            {
                ProcesarEstado9();
            }
            else if ("q10".Equals(estadoActual))
            {
                ProcesarEstado10();
            }
            else if ("q11".Equals(estadoActual))
            {
                ProcesarEstado11();
            }
            else if ("q12".Equals(estadoActual))
            {
                ProcesarEstado12();
            }
            else if ("q13".Equals(estadoActual))
            {
                ProcesarEstado13();
            }
            else if ("q14".Equals(estadoActual))
            {
                ProcesarEstado14();
            }
            else if ("q15".Equals(estadoActual))
            {
                ProcesarEstado15();
            }
            else if ("q16".Equals(estadoActual))
            {
                ProcesarEstado16();
            }
            else if ("q17".Equals(estadoActual))
            {
                ProcesarEstado17();
            }
            else if ("q18".Equals(estadoActual))
            {
                ProcesarEstado18();
            }
            else if ("q19".Equals(estadoActual))
            {
                ProcesarEstado19();
            }
            else if ("q20".Equals(estadoActual))
            {
                ProcesarEstado20();
            }
            else if ("q21".Equals(estadoActual))
            {
                ProcesarEstado21();
            }
            else if ("q22".Equals(estadoActual))
            {
                ProcesarEstado22();
            }
            else if ("q23".Equals(estadoActual))
            {
                ProcesarEstado23();
            }
            else if ("q24".Equals(estadoActual))
            {
                ProcesarEstado25();
            }
            else if ("q26".Equals(estadoActual))
            {
                ProcesarEstado26();
            }
            else if ("q27".Equals(estadoActual))
            {
                ProcesarEstado27();
            }
            else if ("q28".Equals(estadoActual))
            {
                ProcesarEstado28();
            }
            else if ("q29".Equals(estadoActual))
            {
                ProcesarEstado29();
            }
            else if ("q30".Equals(estadoActual))
            {
                ProcesarEstado30();
            }
            else if ("q31".Equals(estadoActual))
            {
                ProcesarEstado31();
            }
            else if ("q32".Equals(estadoActual))
            {
                ProcesarEstado32();
            }
            else if ("q33".Equals(estadoActual))
            {
                ProcesarEstado33();
            }
            else if ("q34".Equals(estadoActual))
            {
                ProcesarEstado34();
            }
            else if ("q35".Equals(estadoActual))
            {
                ProcesarEstado35();
            }
            else if ("q36".Equals(estadoActual))
            {
                ProcesarEstado36();
            }
            else if ("q37".Equals(estadoActual))
            {
                ProcesarEstado37();
            }
            else if ("q38".Equals(estadoActual))
            {
                ProcesarEstado38();
            }
            else if ("q39".Equals(estadoActual))
            {
                ProcesarEstado39();
            }
            else if ("q40".Equals(estadoActual))
            {
                ProcesarEstado40();
            }
            else if ("q41".Equals(estadoActual))
            {
                ProcesarEstado41();
            }
            else if ("q42".Equals(estadoActual))
            {
                ProcesarEstado42();
            }
            else if ("q43".Equals(estadoActual))
            {
                ProcesarEstado43();
            }
            else if ("q44".Equals(estadoActual))
            {
                ProcesarEstado44();
            }
            else if ("q45".Equals(estadoActual))
            {
                ProcesarEstado45();
            }
            else if ("q46".Equals(estadoActual))
            {
                ProcesarEstado46();
            }
            else if ("q47".Equals(estadoActual))
            {
                ProcesarEstado47();
            }
            else if ("q48".Equals(estadoActual))
            {
                ProcesarEstado48();
            }
            else if ("q49".Equals(estadoActual))
            {
                ProcesarEstado49();
            }
            else if ("q50".Equals(estadoActual))
            {
                ProcesarEstado50();
            }
            else if ("q51".Equals(estadoActual))
            {
                ProcesarEstado51();
            }
            else if ("q52".Equals(estadoActual))
            {
                ProcesarEstado52();
            }
            else if ("q53".Equals(estadoActual))
            {
                ProcesarEstado53();
            }
            else if ("q54".Equals(estadoActual))
            {
                ProcesarEstado54();
            }
            else if ("q55".Equals(estadoActual))
            {
                ProcesarEstado55();
            }
            else if ("q56".Equals(estadoActual))
            {
                ProcesarEstado56();
            }
            else if ("q57".Equals(estadoActual))
            {
                ProcesarEstado57();
            }
            else if ("q58".Equals(estadoActual))
            {
                ProcesarEstado58();
            }
            else if ("q59".Equals(estadoActual))
            {
                ProcesarEstado59();
            }
            else if ("q61".Equals(estadoActual))
            {
                ProcesarEstado61();
            }
            else if ("q62".Equals(estadoActual))
            {
                ProcesarEstado62();
            }
            else if ("q63".Equals(estadoActual))
            {
                ProcesarEstado63();
            }
            else if ("q64".Equals(estadoActual))
            {
                ProcesarEstado64();
            }
            else if ("q65".Equals(estadoActual))
            {
                ProcesarEstado65();
            }
            else if ("q66".Equals(estadoActual))
            {
                ProcesarEstado66();
            }
            else if ("q67".Equals(estadoActual))
            {
                ProcesarEstado67();
            }
            else if ("q68".Equals(estadoActual))
            {
                ProcesarEstado68();
            }
            else if ("q69".Equals(estadoActual))
            {
                ProcesarEstado69();
            }
            else if ("q71".Equals(estadoActual))
            {
                ProcesarEstado71();
            }
            else if ("q72".Equals(estadoActual))
            {
                ProcesarEstado72();
            }
            else if ("q73".Equals(estadoActual))
            {
                ProcesarEstado73();
            }
            else if ("q74".Equals(estadoActual))
            {
                ProcesarEstado74();
            }
            else if ("q75".Equals(estadoActual))
            {
                ProcesarEstado75();
            }
            else if ("q76".Equals(estadoActual))
            {
                ProcesarEstado76();
            }
            else if ("q78".Equals(estadoActual))
            {
                ProcesarEstado78();
            }
            else if ("q79".Equals(estadoActual))
            {
                ProcesarEstado79();
            }
            else if ("q81".Equals(estadoActual))
            {
                ProcesarEstado81();
            }
        }
        return lexema;

    }
    private void ProcesarEstado1()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if 
        {
            estadoActual == A || estadoActual == a;
        }
        else if 
        {
            estadoActual == a || estadoActual == A;
        }
    }

    private void ProcesarEstado2()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == B || estadoActual == b;
        }
        else if
        {
            estadoActual == b || estadoActual == B;
        }
    }
    private void ProcesarEstado3()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == C  || estadoActual == c ;
        }
        else if
        {
            estadoActual ==c  || estadoActual == C;
        }
    }

    private void ProcesarEstado4()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == D || estadoActual == d ;
        }
        else if
        {
            estadoActual == d || estadoActual == D ;
        }
    }

    private void ProcesarEstado5()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == E  || estadoActual ==e ;
        }
        else if
        {
            estadoActual == e || estadoActual == E;
        }
    }
    private void ProcesarEstado6()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == F  || estadoActual ==f ;
        }
        else if
        {
            estadoActual == f || estadoActual == F;
        }
    }
    private void ProcesarEstado7()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == G || estadoActual == g ;
        }
        else if
        {
            estadoActual == g || estadoActual == G;
        }
    }
    private void ProcesarEstado8()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == H || estadoActual == h;
        }
        else if
        {
            estadoActual == h || estadoActual == H;
        }
    }
    private void ProcesarEstado9()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == I || estadoActual ==i ;
        }
        else if
        {
            estadoActual == i || estadoActual ==I ;
        }
    }
    private void ProcesarEstado10()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == J || estadoActual ==j ;
        }
        else if
        {
            estadoActual == j || estadoActual == J ;
        }
    }
    private void ProcesarEstado11()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == K || estadoActual ==k ;
        }
        else if
        {
            estadoActual == k || estadoActual == K;
        }
    }
    private void ProcesarEstado12()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == L || estadoActual ==l ;
        }
        else if
        {
            estadoActual == l || estadoActual == L;
        }
    }
    private void ProcesarEstado13()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == M || estadoActual ==m ;
        }
        else if
        {
            estadoActual == m || estadoActual == M;
        }
    }
    private void ProcesarEstado14()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == N || estadoActual ==n ;
        }
        else if
        {
            estadoActual == n || estadoActual ==N ;
        }
    }
    private void ProcesarEstado15()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Ñ || estadoActual ==ñ ;
        }
        else if
        {
            estadoActual == ñ || estadoActual ==Ñ ;
        }
    }
    private void ProcesarEstado16()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == O || estadoActual == o;
        }
        else if
        {
            estadoActual == o || estadoActual == O;
        }
    }
    private void ProcesarEstado17()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == P || estadoActual == p;
        }
        else if
        {
            estadoActual == p || estadoActual == P ;
        }
    }
    private void ProcesarEstado18()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Q || estadoActual ==q ;
        }
        else if
        {
            estadoActual == q || estadoActual == Q ;
        }
    }
    private void ProcesarEstado19()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == R || estadoActual ==r ;
        }
        else if
        {
            estadoActual == r || estadoActual == R;
        }
    }
    private void ProcesarEstado20()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == S || estadoActual ==s ;
        }
        else if
        {
            estadoActual == s || estadoActual == S ;
        }
    }
    private void ProcesarEstado21()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == T || estadoActual == t ;
        }
        else if
        {
            estadoActual == t || estadoActual == T;
        }
    }
    private void ProcesarEstado22()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == U  || estadoActual == u;
        }
        else if
        {
            estadoActual == u || estadoActual == U;
        }
    }
    private void ProcesarEstado23()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == V || estadoActual == v;
        }
        else if
        {
            estadoActual == v || estadoActual == V;
        }
    }
    private void ProcesarEstado24()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == W  || estadoActual ==w;
        }
        else if
        {
            estadoActual == w || estadoActual == W;
        }
    }
    private void ProcesarEstado25()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == X || estadoActual == x;
        }
        else if
        {
            estadoActual == x || estadoActual == X;
        }
    }
    private void ProcesarEstado26()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Y || estadoActual ==y;
        }
        else if
        {
            estadoActual == y || estadoActual == Y;
        }
    }
    private void ProcesarEstado27()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Z || estadoActual == z;
        }
        else if
        {
            estadoActual == z || estadoActual == Z;
        }
    }
    private void ProcesarEstado28()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Á || estadoActual == á;
        }
        else if
        {
            estadoActual == á || estadoActual ==Á;
        }
    }
    private void ProcesarEstado29()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == É || estadoActual ==é;
        }
        else if
        {
            estadoActual == é || estadoActual ==É;
        }
    }
    private void ProcesarEstado30()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Í || estadoActual ==í ;
        }
        else if
        {
            estadoActual == í || estadoActual == Í ;
        }
    }
    private void ProcesarEstado31()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Ó || estadoActual == ó;
        }
        else if
        {
            estadoActual == ó || estadoActual == Ó;
        }
    }
    private void ProcesarEstado32()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Ú || estadoActual ==ú;
        }
        else if
        {
            estadoActual == ú || estadoActual ==Ú;
        }
    }
    private void ProcesarEstado33()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == Ü || estadoActual == ü;
        }
        else if
        {
            estadoActual == ü || estadoActual == Ü;
        }
    }
    private void ProcesarEstado34()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 0;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado35()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 1;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado36()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 2;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado37()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 3;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado38()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 4;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado39()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 5;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado40()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 6;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado41()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 7;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado42()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 8;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }
    private void ProcesarEstado43()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if
        {
            estadoActual == 9;
        }
        else if
        {
            estadoActual == [0 - 9];
        }
    }

    private void ProcesarEstado44()
    {
        categoria = "RETORNO COMA";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado45()
    {
        categoria = "RETORNO PUNTO Y COMA";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado46()
    {
        categoria = "RETORNO PUNTO";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado47()
    {
        categoria = "DOS PUNTOS";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado48()
    {
        categoria = "RETORNO PARENTESIS ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado49()
    {
        categoria = "RETORNA PARENTESIS CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }

    private void ProcesarEstado50()
    {
        categoria = "RETORNAR CORCHETE ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado51()
    {
        categoria = "RETORNAR CORCHETE CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado52()
    {
        categoria = "RETORNAR LLAVE ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado53()
    {
        categoria = "RETORNAR LLAVE CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado54()
    {
        categoria = "RETORNAR NUMERAL>";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado55()
    {
        categoria = "RETORNAR SIMBOLO PESO";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado56()
    {
        categoria = "RETORNAR SIMBOLO AMPERSAND";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado57()
    {
        categoria = "RETORNAR SIMBOLO ARROBA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado58()
    {
        categoria = "RETORNAR SIMBOLO SUMA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado59()
    {
        categoria = "RETORNAR SIMBOLO  RESTA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado60()
    {
        categoria = "RETORNAR SIMBOLO MULTIPLICACION";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado61()
    {
        Concatenar();
        LeerSiguienteCaracter();

        if (UtilTexto.EsSimbolo(caracterActual))
        {
            estadoActual = "";
        }
        else
        {
            estadoActual = "";
        }
         else
        {
            estadoActual = "";
        }

    }
    private void ProcesarEstado62()
    {
        categoria = "RETORNAR SIMBOLO MODULO";
        FormarComponenteLexico();
        continuarAnalisis = false;

    }
    private void ProcesarEstado63()
    {
        categoria = "RETORNAR SIMBOLO ASIGNACION";
        FormarComponenteLexico81();
        continuarAnalisis = false;
    }
    private void ProcesarEstado64()
    {
        categoria = "RETORNAR SIMBOLO BARRA   INVERTIDA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado65()
    {
        categoria = "RETORNAR SIMBOLO PLECA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado66()
    {
        categoria = "RETORNAR SIMBOLO COMILLAS";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado67()
    {
        categoria = "RETORNAR SIMBOLO  APOSTROFE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado68()
    {
        categoria = "RETORNAR SIMBOLO  ACENTO CIRCUNFLEJO";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado69()
    {
        categoria = "RETORNAR SIMBOLO  ADMIRACION CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado70()
    {
        categoria = "RETORNAR SIMBOLO  ADMIRACION ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado71()
    {
        categoria = "RETORNAR SIMBOLO  INTERROGACION ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado72()
    {
        categoria = "RETORNAR SIMBOLO  INTERROGACION CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado73()
    {
        categoria = "RETORNAR SIMBOLO  GUION BAJO";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado74()
    {
        categoria = "RETORNAR SIMBOLO  SIGNO MAYOR QUE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado75()
    {
        categoria = "ETORNAR SIMBOLO  SIGNO MENOR QUE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado76()
    {
        categoria = "RETORNAR SIMBOLO  A VOLADA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado77()
    {
        categoria = "RETORNAR SIMBOLO  O VOLADA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado78()
    {
        categoria = "RETORNAR SIMBOLO  VIRGUILILLA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado79()
    {
        categoria = "RETORNAR SIMBOLO  ANTILAMBADA ABRE";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado80()
    {
        categoria = "RETORNAR SIMBOLO  ANTILAMBADA CIERRA";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }
    private void ProcesarEstado81()
    {
        categoria = "RETORNAR SIMBOLO ESPACIO";
        FormarComponenteLexico();
        continuarAnalisis = false;
    }

    private void FormarCamponenteLexico()
    {
        posicionInicial = puntero - lexema.Length;
        posicionFinal = puntero - 1;

        Console.WriteLine("Categoria: " + Categoria);
        Console.WriteLine("lexema: " + lexema);
        Console.WriteLine("Numero Linea: " + numeroLineaActual);
        Console.WriteLine("Posicion Inicial: " + posicionInicial);
        Console.WriteLine("Posicion Final: " + posicionFinal);


    }

    private void DevorarEspacionBlanco()
    {
        while ("".Equals(caracterActual.Trim()) || "    ".Equals(caracterActual))
        {
            LeerSiguienteCaracter();
        }
    }





}
