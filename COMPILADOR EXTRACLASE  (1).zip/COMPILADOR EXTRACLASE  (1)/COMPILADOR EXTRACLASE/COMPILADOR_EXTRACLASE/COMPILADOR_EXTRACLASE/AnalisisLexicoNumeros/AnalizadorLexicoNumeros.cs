﻿using COMPILADOR_EXTRACLASE.CACHE;
using COMPILADOR_EXTRACLASE.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMPILADOR_EXTRACLASE.AnalisisLexicoNumeros
{
    public class AnalizadorLexicoNumeros
    {


        private int numeroLineaActual = 0;
        private string contenidoLineaActual = "";
        private int puntero = 0;
        private string caracterActual = "";
        private string lexema = "";
        private string Categoria = "";
        private string estadoActual = "";
        private int posicionInicial = 0;
        private int posicionFinal = 0;
        private bool continuarAnalisis = false;

        public AnalizadorLexicoNumeros()
        {
            CargarNuevaLinea();
        }



        private void CargarNuevaLinea()
        {
            if (!"@eof@".Equals(contenidoLineaActual))
            {
                numeroLineaActual += 1;
                contenidoLineaActual = DataCache.ObtenerLinea(numeroLineaActual).Contenido;
                numeroLineaActual = DataCache.ObtenerLinea(numeroLineaActual).NumeroLinea;
                puntero = 1;
            }


        }

        private void LeerSiguienteCaracter()
        {
            if (!"@eof@".Equals(contenidoLineaActual))
            {
                caracterActual = "@eof@";
            }
            else if (puntero > contenidoLineaActual.Length)
            {
                caracterActual = "@eof@";
            }
            else
            {
                caracterActual = contenidoLineaActual.Substring(puntero - 1, 1);
                puntero = puntero + 1;

            }

            //PARA VER RESULTADOS
            while ("@EOF".Equals(caracterActual))
            {
                DevolverSiguienteComponente();
            }

        }

        private void DevolverPuntero()
        {
            puntero -= 1;

        }
        private void Concatenar()
        {
            lexema += caracterActual;

        }

        private void Resetear()
        {
            estadoActual = "q0";
            lexema = "";
            Categoria = "";
            posicionInicial = 0;
            posicionFinal = 0;
            caracterActual = "";
            continuarAnalisis = true;
        }


        public void DevolverSiguienteComponente()
        {
            Resetear();
            while (continuarAnalisis)
            {
                if ("q0".Equals(estadoActual))
                {
                    ProcesarEstado0();
                }else if ("q1".Equals(estadoActual)) {

                    ProcesarEstado1();
                
                }else if ("q2".Equals(estadoActual))
                {
                    ProcesarEstado2();
                }
                else if ("q3".Equals(estadoActual))
                {
                    ProcesarEstado3();
                }
                else if ("q4".Equals(estadoActual))
                {
                    ProcesarEstado4();
                }
                else if ("q5".Equals(estadoActual))
                {
                    ProcesarEstado5();
                }

            }
        }
        private void ProcesarEstado1()
        {
            DevorarEspacionBlanco();
            if
            {
                estadoActual == 11 || estadoActual == A || estadoActual == .  .;
            }
            else if
            {
                estadoActual == 11 || estadoActual == a || estadoActual == .  .;
            }
        }
        private void ProcesarEstado2()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 12 || estadoActual == B || estadoActual == . ..;
            }
            else if
            {
                estadoActual == 12 || estadoActual == b || estadoActual == . ..;
            }
        }
        private void ProcesarEstado3()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 13 || estadoActual == C || estadoActual == . ...;
            }
            else if
            {
                estadoActual == 13 || estadoActual == c || estadoActual == . ...;
            }
        }

        private void ProcesarEstado4()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 14 || estadoActual == D || estadoActual == . ....;
            }
            else if
            {
                estadoActual == 14 || estadoActual == d || estadoActual == . ....;
            }
        }

        private void ProcesarEstado5()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 15 || estadoActual == E || estadoActual == . .....;
            }
            else if
            {
                estadoActual == 15 || estadoActual == e || estadoActual == . .....;
            }
        }
        private void ProcesarEstado6()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 16 || estadoActual == F || estadoActual == . ......;
            }
            else if
            {
                estadoActual == 16 || estadoActual == f || estadoActual == . ......;
            }
        }
        private void ProcesarEstado7()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 17 || estadoActual == G || estadoActual == . .......;
            }
            else if
            {
                estadoActual == 17 || estadoActual == g || estadoActual == . .......;
            }
        }
        private void ProcesarEstado8()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 18 || estadoActual == H || estadoActual == . ........;
            }
            else if
            {
                estadoActual == 18 || estadoActual == h || estadoActual == . ........;
            }
        }
        private void ProcesarEstado9()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 19 || estadoActual == I || estadoActual == . .........;
            }
            else if
            {
                estadoActual == 19 || estadoActual == i || estadoActual == . .........;
            }
        }
        private void ProcesarEstado10()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 21 || estadoActual == J || estadoActual == .. .;
            }
            else if
            {
                estadoActual == 21 || estadoActual == j || estadoActual == .. .;
            }
        }
        private void ProcesarEstado11()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 22 || estadoActual == K || estadoActual == ....;
            }
            else if
            {
                estadoActual == 22 || estadoActual == k || estadoActual == ....;
            }
        }
        private void ProcesarEstado12()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 23 || estadoActual == L || estadoActual == .....;
            }
            else if
            {
                estadoActual == 23 || estadoActual == l || estadoActual == .....;
            }
        }
        private void ProcesarEstado13()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 24 || estadoActual == M || estadoActual == ......;
            }
            else if
            {
                estadoActual == 24 || estadoActual == m || estadoActual == ......;
            }
        }
        private void ProcesarEstado14()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 25 || estadoActual == N || estadoActual == .......;
            }
            else if
            {
                estadoActual == 25 || estadoActual == n || estadoActual == .......;
            }
        }
        private void ProcesarEstado15()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 26 || estadoActual == Ñ || estadoActual == ........;
            }
            else if
            {
                estadoActual == 26 || estadoActual == ñ || estadoActual == ........;
            }
        }
        private void ProcesarEstado16()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 27 || estadoActual == O || estadoActual == .........;
            }
            else if
            {
                estadoActual == 27 || estadoActual == o || estadoActual == .........;
            }
        }
        private void ProcesarEstado17()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 28 || estadoActual == P || estadoActual == ..........;
            }
            else if
            {
                estadoActual == 28 || estadoActual == p || estadoActual == ..........;
            }
        }
        private void ProcesarEstado18()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 29 || estadoActual == Q || estadoActual == ...........;
            }
            else if
            {
                estadoActual == 29 || estadoActual == q || estadoActual == ...........;
            }
        }
        private void ProcesarEstado19()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 31 || estadoActual == R || estadoActual == ... .;
            }
            else if
            {
                estadoActual == 31 || estadoActual == r || estadoActual == ... .;
            }
        }
        private void ProcesarEstado20()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 32 || estadoActual == S || estadoActual == ... ..;
            }
            else if
            {
                estadoActual == 32 || estadoActual == s || estadoActual == ... ..;
            }
        }
        private void ProcesarEstado21()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 33 || estadoActual == T || estadoActual == ... ...;
            }
            else if
            {
                estadoActual == 33 || estadoActual == t || estadoActual == ... ...;
            }
        }
        private void ProcesarEstado22()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 34 || estadoActual == U || estadoActual == ... ....;
            }
            else if
            {
                estadoActual == 34 || estadoActual == u || estadoActual == ... ....;
            }
        }
        private void ProcesarEstado23()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 35 || estadoActual == V || estadoActual == ... .....;
            }
            else if
            {
                estadoActual == 35 || estadoActual == v || estadoActual == ... .....;
            }
        }
        private void ProcesarEstado24()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 36 || estadoActual == W || estadoActual == ... ......;
            }
            else if
            {
                estadoActual == 36 || estadoActual == w || estadoActual == ... ......;
            }
        }
        private void ProcesarEstado25()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 37 || estadoActual == X || estadoActual == ... .......;
            }
            else if
            {
                estadoActual == 37 || estadoActual == x || estadoActual == ... .......;
            }
        }
        private void ProcesarEstado26()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 38 || estadoActual == Y || estadoActual == ... ........;
            }
            else if
            {
                estadoActual == 38 || estadoActual == y || estadoActual == ... ........;
            }
        }
        private void ProcesarEstado27()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 39 || estadoActual == Z || estadoActual == ... .........;
            }
            else if
            {
                estadoActual == 39 || estadoActual == z || estadoActual == ... .........;
            }
        }
        private void ProcesarEstado28()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 41 || estadoActual == Á || estadoActual == .... .;
            }
            else if
            {
                estadoActual == 41 || estadoActual == á || estadoActual == .... .;
            }
        }
        private void ProcesarEstado29()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 42 || estadoActual == É || estadoActual == ......;
            }
            else if
            {
                estadoActual == 42 || estadoActual == é || estadoActual == ......;
            }
        }
        private void ProcesarEstado30()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 43 || estadoActual == Í || estadoActual == .......;
            }
            else if
            {
                estadoActual == 43 || estadoActual == í || estadoActual == .......;
            }
        }
        private void ProcesarEstado31()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 44 || estadoActual == Ó || estadoActual == ........;
            }
            else if
            {
                estadoActual == 44 || estadoActual == ó || estadoActual == ........;
            }
        }
        private void ProcesarEstado32()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 45 || estadoActual == Ú || estadoActual == .........;
            }
            else if
            {
                estadoActual == 45 || estadoActual == ú || estadoActual == .........;
            }
        }
        private void ProcesarEstado33()
        {
            Concatenar();
            LeerSiguienteCaracter();

            if
            {
                estadoActual == 46 || estadoActual == Ü || estadoActual == ..........;
            }
            else if
            {
                estadoActual == 46 || estadoActual == ü || estadoActual == ..........;
            }
        }
        

        private void FormarCamponenteLexico()
        {
            posicionInicial = puntero - lexema.Length;
            posicionFinal = puntero - 1;

            Console.WriteLine("Categoria: " + Categoria);
            Console.WriteLine("lexema: " + lexema);
            Console.WriteLine("Numero Linea: " + numeroLineaActual);
            Console.WriteLine("Posicion Inicial: " + posicionInicial);
            Console.WriteLine("Posicion Final: " + posicionFinal);


        }

        private void DevorarEspacionBlanco()
        {
            while ("".Equals(caracterActual.Trim()) || "    ".Equals(caracterActual))
            {
                LeerSiguienteCaracter();
            }
        }
    }
}
